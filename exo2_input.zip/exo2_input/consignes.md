# Formulaire d'inscription

Tenez bon, ça à l'air long mais ça va ^^'

*Uniquement à l'aide du main.js*
Commencez par créer 4 labels : Nom, Prénom, Age et Adresse e-mail.
Ensuite, créez 4 inputs (/!\ aux valeurs que vous les assignerez).

Mettez vos balises dans le bon ordre, de sorte que cela fasse : label1 input1, label2 input2, label3 input3, label4 input4.

Ciblez la bonne balise et stockez sa valeur.

L'inscription sera conclue à l'aide d'un event "double clic" (sur toute la page)

Si l'utilisateur est majeur affichez : Vous avez X ans : Inscription réussie`.
Au contraire, si l'utilisateur est mineur, affichez : Vous avez X ans : Accès refusé aux mineurs


== Un preview est disponible dans ce dossier :)

En gros:
Remplissez tous les inputs avec vos informations et validez l'inscription en doucle-cliquant n'importe où sur la page. Un message d'alerte s'affichera.
